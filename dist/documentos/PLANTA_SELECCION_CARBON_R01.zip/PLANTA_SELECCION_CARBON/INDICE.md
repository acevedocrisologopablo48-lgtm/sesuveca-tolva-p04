# Planta selección carbón R01

SESUVECA / JAVIER ACEVEDO. Implantación de equipos para revisión, 28/10/2026.

- [Conjunto SolidWorks](01_CAD_3D/PLANTA_SELECCION_CARBON_R01.SLDASM): tolva y dos fajas S, con posiciones 0°, 35° y 70°.
- [STEP del conjunto](05_INTERCAMBIO/PLANTA_SELECCION_CARBON_R01.step): copia geométrica independiente en posición de carga.
- [Láminas de distribución](02_IMPLANTACION/PLANTA_SELECCION_CARBON_IMPLANTACION_R01.pdf): 3 páginas A4 con recorrido de material y cotas.
- [Vista general](02_IMPLANTACION/PLANTA_COMPLETA_R01.png), [planta](02_IMPLANTACION/PLANTA_SUPERIOR_R01.png) y [perfil](02_IMPLANTACION/PERFIL_LONGITUDINAL_R01.png).

El nativo referencia las carpetas de los equipos originales. Mantenerlas accesibles en este equipo. El STEP sirve para revisión sin esas referencias. La zona verde es reserva de operarios; leer LEEME.md para el alcance.

La distribución mantiene 200 mm entre la parte inferior de la horizontal y la altura máxima de la tolva al girar. No reemite la ingeniería de fabricación de los equipos.
