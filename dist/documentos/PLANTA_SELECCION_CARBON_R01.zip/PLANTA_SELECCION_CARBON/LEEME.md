# Planta de selección de carbón

Implantación R01 para revisión espacial. SESUVECA / JAVIER ACEVEDO. 28/10/2026.

Abrir `01_CAD_3D/PLANTA_SELECCION_CARBON_R01.SLDASM`. El ensamblaje reúne la tolva vigente C05 con geometría C06 y las dos fajas de revisión S. Los diseños fuente mantienen sus archivos y dimensiones. Conservar accesibles sus carpetas originales: el conjunto utiliza referencias a ellas.

La faja horizontal se coloca al costado contrario a la descarga de la tolva, paralela a su lado largo. El material aceptado continúa a la inclinada; el rechazo se desvía lateralmente hacia la tolva en posición de carga. Las configuraciones de revisión muestran 0°, 35° y 70°.

Se adoptan 200 mm entre el punto inferior del bastidor horizontal y la cota máxima del barrido de la tolva. El centro de la banda horizontal resulta a 5146,6 mm del piso. El rectángulo verde reserva el espacio de operarios a 1000 mm bajo ese centro; no es una pasarela estructural terminada ni incluye accesos o protecciones diseñados.

La inclinada conserva 19,179° y la transferencia original respecto a la horizontal. Se resolvieron los 14 pares candidatos de cruce mediante intersección de sólidos STEP: ninguno presenta volumen común. No se alteran piezas de las fajas para reunir los equipos.

Vistas y láminas: `02_IMPLANTACION/`. Copia geométrica independiente: `05_INTERCAMBIO/`. Transformaciones, fuentes y comprobaciones de separación de equipos: `04_VERIFICACION/`. Scripts reproducibles: `07_FUENTES/`.

Este conjunto define posiciones de planta para revisión. No cambia el estado resistente ni la liberación de fabricación de los equipos originales y no añade un cálculo de sus nuevas estructuras elevadas.

Entre el borde de la banda y la boca se dejan aproximadamente 481 mm horizontales; la caída al labio de carga es de 1983 mm. El desvío del rechazo se indica con una flecha de recorrido: no se ha añadido una canaleta fabricable ni simulado el vuelo de las piedras. La zona de selección funciona con la tolva en 0°; no se representa aporte de rechazo durante el basculamiento.
